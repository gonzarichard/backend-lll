import mongoose from 'mongoose';

const collection = 'pets';

const schema = new mongoose.Schema({
    name:{
        type:String,
        required:true,
    },
    specie:{
        type:String,
        required:true
    },
    birthDate:Date,
    adopted:{
        type:Boolean,
        default:false
    },
    owner:{
        type:mongoose.SchemaTypes.ObjectId,
        ref:'users'
    },
    image:String
})

const petModel = mongoose.model(collection,schema);

export default petModel;